package com.example.acharyaji.Adapters;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.example.acharyaji.Models.Get_Main_Categories;
import com.example.acharyaji.R;

import java.util.List;


public class Main_Categories_Adapter_api extends RecyclerView.Adapter<Main_Categories_Adapter_api.holder> {

    Context context;

    private List<Get_Main_Categories> main_categories_models;
//    Context context;
//    int[] images;
//    String[] title;


//    public Interior_Adapter(Context context, int[] images, String[] title) {
//        this.context = context;
//        this.images = images;
//        this.title = title;
//
//    }


    public Main_Categories_Adapter_api(Context context, List<Get_Main_Categories> main_categories_models) {
        this.context = context;
        this.main_categories_models = main_categories_models;
    }

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grid_list_item_product, parent, false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position) {

        Log.d("chekposition","position is"+ position);


        Get_Main_Categories model =main_categories_models.get(position);
//        SubCat_Item_Model_api model =subCat_item_model_apis.get(position);



//        String   sublinks=  model.getLinks().getSub_categories();
//
//        Log.d("sublinks","  sublinks are " +  sublinks);
//        String name =model.getName();
//        String banner =model.getBanner();
//
//        String maincatimage=model.getIcon();









        holder.product_title.setText(model.getTitle());
        holder.subtitle.setText(model.getSubtitle());
        holder.product_price.setText(String.valueOf(model.getAmount()) );


        Glide.with(context)
                .load(model.getCoverImage())
                .placeholder(R.drawable.placeimg)
                .into(holder.product_iamge);





//        Glide.with(context).load(images[position]).into(holder.product_iamge);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                context.startActivity(new Intent(context, Interior_Categories_Activity.class));


//
//
//                Intent i = new Intent(context, Categories_Activity.class);
//                i.putExtra("position", "" + new Gson().toJson(model));
//                i.putExtra("mainidname",name);
//                i.putExtra("maincatimage",maincatimage);
//                i.putExtra("sublinks",sublinks);
//                i.putExtra("banner",banner);
//
//
//                context.startActivity(i);







               /* Intent intent = new Intent(context, Activity_Subcategories_api.class);
                Bundle bundle = new Bundle();
                bundle.putString("named",model+"");
                bundle.putString("slug",slug);
                intent.putExtras(bundle);

              context.startActivity(intent);
*/


//                context.startActivity(new Intent(context, Activity_Subcategories_api.class));
            }
        });
    }

    @Override
    public int getItemCount(){ return  main_categories_models.size();
    }

    public static class holder extends RecyclerView.ViewHolder {

        ImageView product_iamge;
        TextView product_title, product_price, subtitle;

        public holder(@NonNull View itemView) {
            super(itemView);

            product_iamge = itemView.findViewById(R.id.product_image);
            product_title = itemView.findViewById(R.id.category_name);
            subtitle = itemView.findViewById(R.id.txt_productprice);
            product_price = itemView.findViewById(R.id.txt_rating);
        }
    }
}
