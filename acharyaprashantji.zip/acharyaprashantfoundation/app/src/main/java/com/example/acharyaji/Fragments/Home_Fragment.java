package com.example.acharyaji.Fragments;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.acharyaji.Adapters.Main_Categories_Adapter_api;
import com.example.acharyaji.Api.ApiInterface;
import com.example.acharyaji.Models.Get_Main_Categories;
import com.example.acharyaji.Utils.utility;
import com.example.acharyaji.databinding.FragmentHomeBinding;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class Home_Fragment extends Fragment {

    ApiInterface apiInterface;
    Main_Categories_Adapter_api main_categories_adapter_api;
    ProgressDialog progressDialog;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }

    FragmentHomeBinding binding;




      @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false);

        Retrofit retrofit = com.example.acharyaji.Api.ApiClient.getclient();
        apiInterface = retrofit.create(com.example.acharyaji.Api.ApiInterface.class);
          progressDialog = new ProgressDialog(getActivity());

        recommendedproducts();

         return binding.getRoot();


  }




    private void setadapter(List<Get_Main_Categories>  get_main_categories) {

        main_categories_adapter_api = new com.example.acharyaji.Adapters.Main_Categories_Adapter_api(getActivity(), get_main_categories);

        GridLayoutManager manager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        binding.rec3.setLayoutManager(manager);
        binding.rec3.setAdapter(main_categories_adapter_api);
        utility.exitDialog(progressDialog);

    }


    public void recommendedproducts() {

        Log.d("apihitsssd","api responce");
          utility.showDialog(progressDialog);

        apiInterface.fetchmaincategories().enqueue(new Callback<List<Get_Main_Categories>>() {



            @Override
            public void onResponse(Call<List<Get_Main_Categories>> call, Response<List<Get_Main_Categories>> response) {



                try {
                    if (response != null) {
                        Log.d("apihit","api responce");

                        Log.d("apihitsssdres","api responce: "+ response);



                        if (response.code()==200) {
                                 //  productModels = response.body();
                           setadapter(response.body());

                            Log.d("apihits","api responce : " + response.body());



                        } else {
                            Toast.makeText(getActivity(), response.code(), Toast.LENGTH_SHORT).show();
                            Log.d("apihitss","api responce");
                            utility.exitDialog(progressDialog);
                        }

                    }

                } catch (Exception e) {
                    Log.e("exp", e.getLocalizedMessage());

                    Log.d("apihitsss","api responce");
                    utility.exitDialog(progressDialog);
                }
            }

            @Override
            public void onFailure(Call<List<Get_Main_Categories>> call, Throwable t) {
                Log.e("failure", t.getLocalizedMessage());

                Log.d("apihitssss","api responce " + t.getLocalizedMessage());
            }
        });

//
    }


}