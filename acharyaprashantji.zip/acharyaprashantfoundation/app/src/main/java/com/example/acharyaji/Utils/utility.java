package com.example.acharyaji.Utils;

import android.app.ProgressDialog;

public class utility {

    public static void showDialog(ProgressDialog progressDialog) {
        progressDialog.setMessage("Please Wait....");
        progressDialog.setCancelable(true);
        progressDialog.show();
    }
    public static void exitDialog(ProgressDialog progressDialog) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
