package com.example.acharyaji.Api;


import com.example.acharyaji.Models.Get_Main_Categories;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {



    @GET("/api/v2/legacy/books")
    Call<List<Get_Main_Categories>> fetchmaincategories();




}
