package com.example.acharyaji.Models;

public class Get_Main_Categories {

    public String id;
    public String type;
    public String title;
    public String subtitle;
    public String language;
    public String coverImage;
    public String shortDescription;
    public int amount;
    public boolean isUpcoming;
    public boolean isDraft;
    public int pages;
    public int copiesTaken;
    public AppleIAP appleIAP;
    public String paperBookURL;
    public boolean showPaperBookInApp;
    public int originalAmount;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCoverImage() {
        return coverImage;
    }

    public void setCoverImage(String coverImage) {
        this.coverImage = coverImage;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public boolean isUpcoming() {
        return isUpcoming;
    }

    public void setUpcoming(boolean upcoming) {
        isUpcoming = upcoming;
    }

    public boolean isDraft() {
        return isDraft;
    }

    public void setDraft(boolean draft) {
        isDraft = draft;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public int getCopiesTaken() {
        return copiesTaken;
    }

    public void setCopiesTaken(int copiesTaken) {
        this.copiesTaken = copiesTaken;
    }

    public AppleIAP getAppleIAP() {
        return appleIAP;
    }

    public void setAppleIAP(AppleIAP appleIAP) {
        this.appleIAP = appleIAP;
    }

    public String getPaperBookURL() {
        return paperBookURL;
    }

    public void setPaperBookURL(String paperBookURL) {
        this.paperBookURL = paperBookURL;
    }

    public boolean isShowPaperBookInApp() {
        return showPaperBookInApp;
    }

    public void setShowPaperBookInApp(boolean showPaperBookInApp) {
        this.showPaperBookInApp = showPaperBookInApp;
    }

    public int getOriginalAmount() {
        return originalAmount;
    }

    public void setOriginalAmount(int originalAmount) {
        this.originalAmount = originalAmount;
    }
}
