package com.example.acharyaji.DashBoadNew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.acharyaji.Fragments.Brand;
import com.example.acharyaji.Fragments.Colour;
import com.example.acharyaji.Fragments.Home_Fragment;
import com.example.acharyaji.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboadmainActivity extends AppCompatActivity {


    private Toolbar mToolbar;
    DrawerLayout drawerLayout;
     RelativeLayout rlSideList;

     TextView txt_myaccount;
    BottomNavigationView bnv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboadmain);

        drawerLayout=findViewById(R.id.drawer_layout);
        rlSideList=findViewById(R.id.side_list);

        txt_myaccount =findViewById(R.id.txt_myaccount);

        bnv=findViewById(R.id.bottomnavigation);

        initToolbar();

        getSupportFragmentManager().beginTransaction().replace(R.id.main_container,new Home_Fragment()).commit();

        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                androidx.fragment.app.Fragment temp=null;

                switch (item.getItemId())
                {
                    case R.id.menu_home :  temp= new Home_Fragment();
                        break;
                    case R.id.menu_book : temp=new Brand();
                        break;
                    case R.id.menu_profile: temp=new Colour();
                        break;
                    case R.id.menu_profiles : temp=new Brand();
                        break;
                    case R.id.menu_profilwe : temp=new Brand();
                        break;

                }
                Log.d("cheking","sfd" +  item.getItemId());

                    getSupportFragmentManager().beginTransaction().replace(R.id.main_container,temp).commit();



                return true;
            }
        });




    }




    private void initToolbar() {

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        setTitle("");

        mToolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
        mToolbar.setNavigationIcon(R.drawable.ic_menu_white_24dp);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openDrawer();

            }
        });


    }


    public void closeDrawer() {
        drawerLayout.closeDrawer(rlSideList);
    }

    public void openDrawer() {

        drawerLayout.openDrawer(rlSideList);
    }


}